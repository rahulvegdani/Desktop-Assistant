import datetime
import pprint
import time
import webbrowser
import pyttsx3
from pywhatkit.sc import shutdown
import speech_recognition
import requests
from bs4 import BeautifulSoup
import os
import pyautogui
import random
import keyboard
from plyer import notification
import speedtest
import winshell
import re
from word2number import w2n
import pyjokes
#from WhatsAppWeb import sendMessage
import pygame.mixer
pygame.mixer.init()


for i in range(3):
    a = input("Enter Password to open :- ")
    pw_file = open("password.txt","r")
    pw = pw_file.read()
    pw_file.close()
    if (a==pw):
        print("WELCOME ! PLZ SPEAK [WAKE UP] TO LOAD ME UP")
        break
    elif (i==2 and a!=pw):
        exit()

    elif (a!=pw):
        print("Try Again")

from INTRO import play_gif
play_gif

engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("voice", voices[0].id)
rate = engine.setProperty("rate",170)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def takeCommand():
    r = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 1
        r.energy_threshold = 300
        audio = r.listen(source,0,4)

    try:
        print("Understanding..")
        query  = r.recognize_google(audio,language='en-in')
        print(f"You Said: {query}\n")
    except Exception as e:
        print("Say that again")
        return "None"
    return query

def alarm(query):
    timehere = open("Alarmtext.txt","a")
    timehere.write(query)
    timehere.close()
    os.startfile("alarm.py")

def get_random_advice():
    res = requests.get("https://api.adviceslip.com/advice").json()
    return res['slip']['advice']

if __name__ == "__main__":
    while True:
        query = takeCommand().lower()
        if "wake up" in query:
            from GreetMe import greetMe
            greetMe()

            while True:
                query = takeCommand().lower()
                if "go to sleep" in query:
                    speak("Ok , You can call me anytime")
                    break

###########################################################################
                elif "change password" in query:
                    speak("What's the new password")
                    new_pw = input("Enter the new password\n")
                    new_password = open("password.txt","w")
                    new_password.write(new_pw)
                    new_password.close()
                    speak("Done")
                    speak(f"Your new password is{new_pw}")

                elif "advice" in query:
                    speak(f"Here's an advice for you, sir")
                    advice = get_random_advice()
                    speak(advice)
                    speak("For your convenience, I am printing it on the screen sir.")
                    print(advice)

                elif "schedule my day" in query:
                    tasks = [] #Empty list
                    speak("Do you want to clear old tasks (Plz speak YES or NO)")
                    query = takeCommand().lower()
                    if "yes" in query:
                        file = open("tasks.txt","w")
                        file.write(f"")
                        file.close()
                        no_tasks = int(input("Enter the no. of tasks :- "))
                        i = 0
                        for i in range(no_tasks):
                            tasks.append(input("Enter the task :- "))
                            file = open("tasks.txt","a")
                            file.write(f"{i}. {tasks[i]}\n")
                            file.close()
                    elif "no" in query:
                        i = 0
                        no_tasks = int(input("Enter the no. of tasks :- "))
                        for i in range(no_tasks):
                            tasks.append(input("Enter the task :- "))
                            file = open("tasks.txt","a")
                            file.write(f"{i}. {tasks[i]}\n")
                            file.close()

                elif "show my schedule" in query:
                    file = open("tasks.txt","r")
                    content = file.read()
                    file.close()
                    pygame.mixer.init()
                    pygame.mixer.music.load("notification.mp3")
                    pygame.mixer.music.play()
                    notification.notify(
                        title = "My schedule :-",
                        message = content,
                        timeout = 15
                    )

                elif "focus mode" in query:
                    a = int(input("Are you sure that you want to enter focus mode :- [1 for YES / 2 for NO "))
                    if (a==1):
                        speak("Entering the focus mode....")
                        os.startfile(r"C:\Users\Lenovo\OneDrive\Desktop\assistant\\FocusMode.py")

                    else:
                        pass

                elif "show my focus" in query:
                    from FocusGraph import focus_graph
                    focus_graph()

                elif "translate" in query:
                    from Translator import translategl
                    query = query.replace("jarvis","")
                    query = query.replace("translate","")
                    translategl(query)

                elif "open" in query:   #EASY METHOD
                    query = query.replace("open","")
                    query = query.replace("jarvis","")
                    pyautogui.press("super")
                    pyautogui.typewrite(query)
                    pyautogui.sleep(2)
                    pyautogui.press("enter")

                elif "internet speed" in query:
                    wifi  = speedtest.Speedtest()
                    upload_net = wifi.upload()/1048576         #Megabyte = 1024*1024 Bytes
                    download_net = wifi.download()/1048576
                    print("Wifi Upload Speed is", upload_net)
                    print("Wifi download speed is ",download_net)
                    speak(f"Wifi download speed is {download_net}")
                    speak(f"Wifi Upload speed is {upload_net}")

                elif "play a game" in query:
                    from game import game_play
                    game_play()

                elif "screenshot" in query:
                     import pyautogui #pip instal pyautogui
                     im = pyautogui.screenshot()
                     im.save("ss.jpg")

                elif "click my photo" in query:
                    pyautogui.press("super")
                    pyautogui.typewrite("camera")
                    pyautogui.press("enter")
                    pyautogui.sleep(2)
                    speak("SMILE")
                    pyautogui.press("enter")

                ##############################

                elif "hello" in query or "hi" in query:
                    speak("Hello, how are you ?")
                elif "not good" in query:
                    speak("I am sorry to hear that." "Anything i can do?")
                elif "i am fine" in query:
                    speak("that's great")
                elif "how are you" in query:
                    speak("Perfect")
                elif "who i am" in query:
                    speak("If you talk then definitely your human.")
                elif "why did you came to the world" in query or "why did u came to the world" in query:
                    speak("Thanks to Rahul. further It's a secret")
                elif "i love you" in query or "i love u" in query:
                    speak("It's hard to understand")
                elif "thank you" in query or "thank u" in query:
                    speak("you are welcome")

                elif 'joke' in query or "tell a joke" in query:
                    joke = pyjokes.get_joke()
                    speak(joke)

                elif "pause" in query:
                    pyautogui.press("k")
                    speak("video paused")
                elif "play" in query:
                    pyautogui.press("k")
                    speak("video played")
                elif "mute" in query:
                    pyautogui.press("m")
                    speak("video muted")

                elif "volume up" in query:
                    from keyboard import volumeup
                    speak("Turning volume up")
                    volumeup()
                elif "volume down" in query:
                    from keyboard import volumedown
                    speak("Turning volume down")
                    volumedown()

                elif "open" in query:
                    from Dictapp import openappweb
                    openappweb(query)
                elif "close" in query:
                    from Dictapp import closeappweb
                    closeappweb(query)

                elif "google" in query:
                    from SearchNow import searchGoogle
                    searchGoogle(query)
                elif "youtube" in query:
                    from SearchNow import searchYoutube
                    searchYoutube(query)
                elif "wikipedia" in query:
                    from SearchNow import searchWikipedia
                    searchWikipedia(query)

                elif "news" in query:
                    from NewsRead import latestnews
                    latestnews()

                elif "calculate" in query:
                    from Calculatenumbers import WolfRamAlpha
                    from Calculatenumbers import Calc
                    query = query.replace("calculate","")
                    query = query.replace("jarvis","")
                    Calc(query)

                elif "whatsapp" in query:
                    from WhatsAppWeb import sendMessage
                    sendMessage()

                elif "weather" in query:
    # Replace 'YOUR_API_KEY' with your actual OpenWeather API key
                    api_key = "2e2bb7aca3b270402d90aa021069eb3f"
                    base_url = "http://api.openweathermap.org/data/2.5/weather?"

                    speak("Please provide the city name:")
                    city_name = takeCommand()

                    complete_url = f"{base_url}q={city_name}&appid={api_key}"
                    response = requests.get(complete_url)
                    data = response.json()

                    if data["cod"] == 200:
                        weather_info = data["weather"][0]
                        main_info = data["main"]

                        temperature_kelvin = main_info["temp"]
                        pressure_hpa = main_info["pressure"]
                        humidity_percent = main_info["humidity"]
                        description = weather_info["description"]

                        # Convert temperature to Celsius
                        temperature_celsius = temperature_kelvin - 273.15

                        speak(f"Weather in {city_name}:")
                        speak(f"Temperature: {temperature_celsius:.2f}°C")
                        speak(f"Pressure: {pressure_hpa} hPa")
                        speak(f"Humidity: {humidity_percent}%")
                        speak(f"Description: {description}")
                    else:
                        speak("City not found or there was an issue with the request.")

                elif "where is" in query:
                        query = query.replace("where is", "")
                        location = query
                        speak("User asked to locate")
                        speak(location)
                        webbrowser.open("https://www.google.nl/maps/place/" + location)

                elif "set an alarm" in query:
                    print("input time example:- 10 and 10 and 10")
                    speak("Set the time")
                    a = input("Please tell the time :- ")
                    alarm(a)
                    speak("Done")

                elif "time" in query:
                    strTime = datetime.datetime.now().strftime("%H:%M")
                    speak(f"Sir, the time is {strTime}")

                elif "don't listen" in query or "stop listening" in query:
                    speak("For how much time do you want to stop from listening to commands? You can specify the duration in seconds or minutes (e.g., '5 seconds' or '2 minutes').")
                    duration_input = takeCommand().lower()
                    duration_in_seconds = 0

                    # Use regular expressions to extract the number and unit (seconds or minutes)
                    match = re.search(r'(\d+) (seconds|minutes)', duration_input)
                    if match:
                        num, unit = match.groups()
                        num = int(num)
                        if unit == 'minutes':
                            num = num * 60  # Convert minutes to seconds
                        duration_in_seconds = num

                    if duration_in_seconds > 0:
                        time.sleep(duration_in_seconds)
                        speak(f"will stop listening for {duration_in_seconds} seconds.")
                    else:
                        speak("Sorry, I couldn't understand the duration. Please specify it in seconds or minutes.")

                elif "remember that" in query:
                    rememberMessage = query.replace("remember that","")
                    rememberMessage = query.replace("jarvis","")
                    speak("You told me to remember that"+rememberMessage)
                    remember = open("Remember.txt","a")
                    remember.write(rememberMessage)
                    remember.close()
                elif "what do you remember" in query:
                    remember = open("Remember.txt","r")
                    speak("You told me to" + remember.read())

                elif 'empty recycle bin' in query:
                    winshell.recycle_bin().empty(confirm = False, show_progress = False, sound = True)
                    speak("Recycle Bin Recycled")

                elif "shutdown the system" in query:
                    speak("Are You sure you want to shutdown")
                    shutdown = input("Do you wish to shutdown your computer? (yes/no)")
                    if shutdown == "yes":
                        os.system("shutdown /s /t 1")
                    elif shutdown == "no":
                        break

                elif "finally sleep" in query:
                    speak("Going to sleep,sir")
                    exit()